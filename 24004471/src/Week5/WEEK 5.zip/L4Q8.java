package Week5;

import java.util.*;
public class L4Q8 {
    public static void main(String[] args) {
        Random random = new Random();
        Scanner sc = new Scanner(System.in);
        System.out.print("\nEnter number of random prime number to be generated:");
        int n = sc.nextInt();
        int i=0;
        while (i!=n){
            int randomNum = random.nextInt(101);
            if (randomNum == 2 || randomNum ==3 || randomNum==5 || randomNum == 7){
                i++;
                System.out.print(randomNum + " ");
            }
            if( randomNum%2!=0 && randomNum%3 !=0 && randomNum%5!=0 && randomNum%7!=0){
                    System.out.print(randomNum + " ");
                    i++;
                           }
        }
            
    }
    }

