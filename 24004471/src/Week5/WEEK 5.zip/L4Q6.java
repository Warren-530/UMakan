
package Week5;

import java.util.Random;
public class L4Q6 {
    public static void main(String[] args) {
        Random random = new Random();
        
        int integer = Math.abs(random.nextInt());
        int i = integer;
        int count=1;
        System.out.println("The random number is "+ integer);
        while (i!=0){
            i = i/10;
            count++;
        }
        System.out.println("Number of digit:" + count);
    }
}
